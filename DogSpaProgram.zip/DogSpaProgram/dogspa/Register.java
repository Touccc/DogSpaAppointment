package dogspa; 

  

public interface Register{ 

  void welcome(); 

  void MakeAppointment(); 

  void Info(); 

} 